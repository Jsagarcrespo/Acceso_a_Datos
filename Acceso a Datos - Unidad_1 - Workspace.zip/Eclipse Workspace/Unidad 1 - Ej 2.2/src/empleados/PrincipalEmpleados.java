package empleados;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collection;
import java.util.List;

import entrada.Teclado;

public class PrincipalEmpleados {

	//Visualizar el menu de opciones
	public static void escribirMenuOpciones() {
		System.out.println("\n0) Salir del programa");
		System.out.println("1) Insertar un empleado en el fichero de texto.");
		System.out.println("2) Consultar todos los empleados del fichero de texto.");
		System.out.println("3) Consultar un empleado, por c�digo, del fichero de texto.");
		System.out.println("4) Actualizar un empleado, por c�digo, del fichero de texto.");
		System.out.println("5) Eliminar un empleado, por c�digo, del fichero de texto.");
	}
	
	public static void main(String[] args) {
		File ficheroEmpleados = new File("data\\empleados.txt");
		File ficheroDepartamentos = new File("data\\departamentos.txt");
		int opcion, codigo, departamento;
		String nombre, fechaAlta;
		double salario;
		Empleado empleado;
		List<Empleado> listaEmpleados;
		List<Departamento> listaDepartamentos;

		do {
			escribirMenuOpciones();
			opcion = Teclado.leerEntero("\nSelecciona una opcion: ");
			
			try {
				switch (opcion) {
				//Salir del programa.
				case 0:
					break;

				//Insertar un empleado en el fichero de texto.
				case 1:
					System.out.println("LISTADO DE DEPARTAMENTOS: ");
					listaDepartamentos = AccesoDepartamentos.leerTodos(ficheroDepartamentos);
					visualizarColeccionDepartamentos(listaDepartamentos);
					codigo = Teclado.leerNatural("C�digo empleado: ");
					if (AccesoEmpleados.consultarEmpleado(ficheroEmpleados, codigo) == null) {
						departamento = Teclado.leerNatural("Departamento: ");
						if (AccesoDepartamentos.consultarDepartamento(ficheroDepartamentos, codigo) != null) {
							nombre = Teclado.leerCadena("Nombre: ");
							fechaAlta = Teclado.leerCadena("Fecha alta: ");
							salario = Teclado.leerReal("Salario: ");
							empleado = new Empleado(codigo, nombre,
									fechaAlta, departamento, salario);
							AccesoEmpleados.insertarEmpleado(empleado,
									ficheroEmpleados);
							System.out.println("Se ha insertado un empleado "
											+ "en el fichero de texto.");
						}
						else {
							System.out.println("No existe ning�n departamento con ese "
											+ "codigo en el fichero de texto.");
						}
					}
					else {
						System.out.println("Ya existe otro empleado con ese "
										+ "codigo en el fichero de texto.");
					}
					break;

				//Consultar todos los empleados del fichero de texto.
				case 2:
					listaEmpleados = AccesoEmpleados.leerTodos(ficheroEmpleados);
					visualizarColeccionEmpleados(listaEmpleados);
					break;

				//Consultar un empleado, por c�digo, del fichero de texto.
				case 3:
					codigo = Teclado.leerNatural("C�digo: ");
					empleado = AccesoEmpleados.consultarEmpleado(ficheroEmpleados, codigo);
					if (empleado == null) {
						System.out.println("No existe ning�n empleado con"
										+ " ese c�digo en el fichero de texto.");
					}
					else {
						System.out.println(empleado.toString());
					}
					break;

				//Actualizar un empleado, por c�digo, del fichero de texto.
				case 4:
					codigo = Teclado.leerNatural("Codigo: ");
					departamento = Teclado.leerNatural("Departamento: ");
					if (AccesoDepartamentos.consultarDepartamento(ficheroDepartamentos, codigo) != null) {
						salario = Teclado.leerReal("Salario: ");
						if (AccesoEmpleados.actualizarEmpleado(ficheroEmpleados,
												codigo, departamento, salario)) {
							System.out.println("Se ha actualizado un empleado del"
											+ " fichero de texto");
						}
						else {
							System.out.println("No existe ning�n empleado con"
											+ " ese codigo en el fichero de texto.");
						}
					}
					else {
						System.out.println("No existe ning�n departamento con ese "
										+ "codigo en el fichero de texto.");
					}
					break;

				//Eliminar un empleado, por c�digo, del fichero de texto.
				case 5:
					codigo = Teclado.leerNatural("C�digo: ");
					if (AccesoEmpleados.eliminarEmpleado(ficheroEmpleados, codigo)) {
						System.out.println("Se ha eliminado un empleado del"
										+ " fichero de texto");
					}
					else {
						System.out.println("No existe ning�n empleado con"
										+ " ese c�digo en el fichero de texto.");
					}
					break;

				//Visualizar mensaje de error por no ser una opcion correcta.
				default:
					System.out.println("La opci�n debe estar entre 0 y 5");
					break;

				}
			}
			catch (FileNotFoundException fnfe) {                      
				System.out.println("Error al abrir el fichero: " + fnfe.getMessage());
				fnfe.printStackTrace();
			}
			catch (IOException ioe) {
				System.out.println("Error al leer/escribir de/en el fichero: " + ioe.getMessage());
				ioe.printStackTrace();
			}
			
		} while (opcion != 0);
	}
	
	//Visualiza una coleccion de empleados
	public static void visualizarColeccionEmpleados(Collection<Empleado> coleccion) {
		if (coleccion.size() == 0) {
			System.out.println("El fichero de texto esta vacio");
		}
		else {
			for (Empleado empleado : coleccion) {
				System.out.println(empleado.toString());
			}
			System.out.println("Se han consultado " + coleccion.size()
							+ " empleados.");
		}
	}
	
	//Visualiza una coleccion de departamentos
	public static void visualizarColeccionDepartamentos(Collection<Departamento> coleccion) {
		if (coleccion.size() == 0) {
			System.out.println("El fichero de texto esta vacio");
		}
		else {
			for (Departamento departamento : coleccion) {
				System.out.println(departamento.toString());
			}
			System.out.println("Se han consultado " + coleccion.size()
							+ " departamentos.");
		}
	}
	
}