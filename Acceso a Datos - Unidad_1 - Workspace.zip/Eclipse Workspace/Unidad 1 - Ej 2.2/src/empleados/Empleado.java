package empleados;

public class Empleado {
	
	//Atributos
	private static String SEPARADOR = ";";
	
	private int codigo;
	private String nombre;
	private String fechaAlta;
	private int departamento;
	private double salario;
	
	//Constructor a partir de parametros
	public Empleado(int codigo, String nombre, String fechaAlta,
					int departamento, double salario) {
		this.codigo = codigo;
		this.nombre = nombre;
		this.fechaAlta = fechaAlta;
		this.departamento = departamento;
		this.salario = salario;
	}
	
	//Constructor a partir de linea de texto
	public Empleado(String linea) {
		String[] lineaSeparada = linea.split(SEPARADOR);
		
		this.codigo = Integer.parseInt(lineaSeparada[0]);
		this.nombre = lineaSeparada[1];
		this.fechaAlta = lineaSeparada[2];
		this.departamento = Integer.parseInt(lineaSeparada[3]);
		this.salario = Double.parseDouble(lineaSeparada[4]);
	}
	
	//Devuelve una cadena de texto con el estado del empleado
	@Override
	public String toString() {
		return "Empleado [codigo = " + codigo +
				", nombre = " + nombre +
				", fechaAlta = " + fechaAlta +
				", departamento = " + departamento +
				", salario = " + String.format("%.2f", salario) + "]";
	}
	
	//Devuelve una cadena de texto con los valores de todos los atributos del objeto,
	//separados entre s� por un separador
	public String toStringWithSeparators() {
		return codigo + SEPARADOR +
				nombre + SEPARADOR +
				fechaAlta + SEPARADOR +
				departamento + SEPARADOR +
				String.format("%.2f", salario).replace(',', '.');
	}
	
	public int getCodigo() {
		return codigo;
	}
	
	public void setDepartamento(int departamento) {
		this.departamento = departamento;
	}
	
	public void setSalario(double salario) {
		this.salario = salario;
	}
}
