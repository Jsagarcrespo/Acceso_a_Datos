package empleados;

public class Departamento {
	
	//Atributos
	private static String SEPARADOR = ";";
	
	private int codigo;
	private String nombre;
	private String ubicacion;
	
	//Constructor a partir de parametros
	public Departamento(int codigo, String nombre, String ubicacion) {
		this.codigo = codigo;
		this.nombre = nombre;
		this.ubicacion = ubicacion;
	}
	
	//Constructor a partir de linea de texto
	public Departamento(String linea) {
		String[] lineaSeparada = linea.split(SEPARADOR);
		
		this.codigo = Integer.parseInt(lineaSeparada[0]);
		this.nombre = lineaSeparada[1];
		this.ubicacion = lineaSeparada[2];
	}
	
	//Devuelve una cadena de texto con el estado del departamento
	@Override
	public String toString() {
		return "Departamento [codigo = " + codigo +
				", nombre = " + nombre +
				", ubicacion = " + ubicacion + "]";
	}
	
	//Devuelve una cadena de texto con los valores de todos los atributos del objeto,
	//separados entre s� por un separador
	public String toStringWithSeparators() {
		return codigo + SEPARADOR +
				nombre + SEPARADOR +
				ubicacion;
	}
	
	public int getCodigo() {
		return codigo;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setUbicacion(String ubicacion) {
		this.ubicacion = ubicacion;
	}
	
}
