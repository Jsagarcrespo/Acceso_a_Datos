package empleados;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AccesoEmpleados {
	//Escribe una linea en un fichero de texto
	public static void insertarEmpleado(Empleado empleado, File fichero)
			throws IOException {
		BufferedWriter flujoEscritura = null;
		try {
			flujoEscritura = new BufferedWriter(new FileWriter(fichero, true));
			String linea = empleado.toStringWithSeparators();
			flujoEscritura.write(linea);
			flujoEscritura.newLine();
		}
		finally {
			if (flujoEscritura != null) {
				flujoEscritura.close();
			}
		}
	}

	//Lee las lineas de un fichero de texto y la guarda en una lista de empleados
	public static List<Empleado> leerTodos(File fichero)
			throws FileNotFoundException, IOException {
		List<Empleado> listaEmpleados = new ArrayList<Empleado>();
		BufferedReader flujoLectura = null;
		try {
			Empleado empleado;
			flujoLectura = new BufferedReader(new FileReader(fichero));
			String linea = flujoLectura.readLine();
			while (linea != null) { 	 
				empleado = new Empleado(linea);
				listaEmpleados.add(empleado);
				linea = flujoLectura.readLine();
			}
		}
		finally {
			if (flujoLectura != null) {
				flujoLectura.close();
			}
		}

		return listaEmpleados;
	}

	
	
	//Consulta un empleado a partir de un codigo en el fichero de texto
	public static Empleado consultarEmpleado(File fichero, int codigo) 
			throws FileNotFoundException, IOException {
		BufferedReader flujoLectura = null;
		Empleado empleado = null;
		try {
			if (fichero.exists()) {
				flujoLectura = new BufferedReader(new FileReader(fichero));
				boolean encontrado = false;
				String linea = flujoLectura.readLine();
				while (linea != null && !encontrado) {
					empleado = new Empleado(linea);
					if (empleado.getCodigo() == codigo) {
						encontrado = true;
					}
					linea = flujoLectura.readLine();
				}

				if (! encontrado) {
					empleado = null;
				}
			}
		}
		finally {
			if (flujoLectura != null) {
				flujoLectura.close();
			}
		}
		return empleado;
	}

	//Actualiza el departamento y el salario de un empleado
	//a partir de un codigo en el fichero de texto
	public static boolean actualizarEmpleado(File fichero, int codigo,
			int departamento, double salario) throws FileNotFoundException, IOException {
		List<Empleado> listaEmpleados = leerTodos(fichero);
		boolean encontrado = false;
		int posicionActualizar = 0;
		Empleado empleado;
		for (int i = 0; i < listaEmpleados.size() && !encontrado; i++) {
			empleado = listaEmpleados.get(i);
			if (empleado.getCodigo() == codigo) {
				encontrado = true;
				posicionActualizar = i;
			}
		}
		if (encontrado) {
			empleado = listaEmpleados.get(posicionActualizar);
			empleado.setDepartamento(departamento);
			empleado.setSalario(salario);
			escribirTodos(listaEmpleados, fichero);
		}

		return encontrado;

	}

	//Elimina un empleado a partir de un codigo en el fichero de texto
	public static boolean eliminarEmpleado(File fichero, int codigo) 
			throws FileNotFoundException, IOException {
		List<Empleado> listaEmpleados = leerTodos(fichero);
		boolean encontrado = false;
		int posicionEliminar = 0;
		Empleado empleado;
		for (int i = 0; i < listaEmpleados.size() && !encontrado; i++) {
			empleado = listaEmpleados.get(i);
			if (empleado.getCodigo() == codigo) {
				encontrado = true;
				posicionEliminar = i;
			}
		}
		if (encontrado) {
			listaEmpleados.remove(posicionEliminar);
			escribirTodos(listaEmpleados, fichero);
		}

		return encontrado;

	}

	//Guarda cada elemento de una lista de empleados en un fichero
	public static void escribirTodos(List<Empleado> listaEmpleados,
			File ficheroEmpleados) throws IOException {
		BufferedWriter flujoEscritura = null;
		try {
			flujoEscritura = new BufferedWriter(new FileWriter(ficheroEmpleados, false));
			Empleado empleado;
			String linea;
			for (int i = 0; i < listaEmpleados.size(); i++) {
				empleado = listaEmpleados.get(i);
				linea = empleado.toStringWithSeparators();
				flujoEscritura.write(linea);
				flujoEscritura.newLine();
			}
		}
		finally {
			if (flujoEscritura != null) {
				flujoEscritura.close();
			}
		}

	}

}
