package empleados;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AccesoDepartamentos {
	//Consulta un departamento a partir de un codigo en el fichero de texto
	public static Departamento consultarDepartamento(File fichero, int codigo) 
			throws FileNotFoundException, IOException {
		BufferedReader flujoLectura = null;
		Departamento departamento = null;
		try {
			if (fichero.exists()) {
				flujoLectura = new BufferedReader(new FileReader(fichero));
				boolean encontrado = false;
				String linea = flujoLectura.readLine();
				while (linea != null && !encontrado) {
					departamento = new Departamento(linea);
					if (departamento.getCodigo() == codigo) {
						encontrado = true;
					}
					linea = flujoLectura.readLine();
				}

				if (! encontrado) {
					departamento = null;
				}
			}
		}
		finally {
			if (flujoLectura != null) {
				flujoLectura.close();
			}
		}
		return departamento;
	}
	
	//Lee las lineas de un fichero de texto y la guarda en una lista de departamentos
	public static List<Departamento> leerTodos(File fichero)
			throws FileNotFoundException, IOException {
		List<Departamento> listaDepartamentos = new ArrayList<Departamento>();
		BufferedReader flujoLectura = null;
		try {
			Departamento departamento;
			flujoLectura = new BufferedReader(new FileReader(fichero));
			String linea = flujoLectura.readLine();
			while (linea != null) { 	 
				departamento = new Departamento(linea);
				listaDepartamentos.add(departamento);
				linea = flujoLectura.readLine();
			}
		}
		finally {
			if (flujoLectura != null) {
				flujoLectura.close();
			}
		}

		return listaDepartamentos;
	}
	
}
