package x4_fichero_binario_aleatorio_datos;

public class Alumno {
	
	private static final int TAMAGNO_REGISTRO = 72;
	private static final int LONGITUD_NOMBRE = 30;
	
	// atributos de objeto
	private int codigo;     // 4 bytes
	private String nombre;  // 30 caracteres de 2 bytes = 60 bytes
	private double nota;    // 8 bytes
	
	// Crea un alumno a partir de 3 par�metros.
	public Alumno(int codigo, String nombre, double nota) {
		this.codigo = codigo;
		StringBuffer buffer = new StringBuffer(nombre);
		buffer.setLength(30);
		this.nombre = buffer.toString();
		this.nota = nota;
	}
	
	// Devuelve una cadena de caracteres con el estado del alumno.
	@Override
	public String toString() {
		return 
			"Alumno [C�digo = " + this.codigo +
			", Nombre = " + this.nombre.trim() +
			", Nota = " + String.format("%.2f", this.nota) +
			"]";
	}

	// Devuelve el tama�o de registro del alumno.
	// Cada car�cter del nombre del alumno se almacena con 2 bytes en el fichero binario.
	public static int getTamagnoRegistro() {
		return TAMAGNO_REGISTRO;
	}
	
	// Devuelve la longitud de nombre del alumno.
	public static int getLongitudNombre() {
		return LONGITUD_NOMBRE;
	}

	// Devuelve el c�digo del alumno.
	public int getCodigo() {
		return this.codigo;
	}

	// Devuelve el nombre del alumno.
	public String getNombre() {
		return this.nombre;
	}

	// Devuelve la nota del alumno.
	public double getNota() {
		return this.nota;
	}

}
