package x4_fichero_binario_aleatorio_datos;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import entrada.Teclado;

public class BuscarAlumnoEnFichero {
  
	// Busca un alumno, por c�digo, en el fichero binario 'alumnos_aleat_datos.dat'.
	// Si el fichero no tiene ning�n alumno con ese c�digo, 
	// escribe en consola un mensaje de alumno no encontrado.
	// Si el fichero tiene un alumno con ese c�digo y el c�digo es v�lido,
	// escribe en consola el alumno.
	// Si el fichero tiene un alumno con ese c�digo y el c�digo es inv�lido,
	// escribe en consola un mensaje de alumno ya eliminado.
  	public static void main(String[] args) {
		RandomAccessFile flujoEntrada = null;
		try {
			int codigo = Teclado.leerEntero("�C�digo? ");
			File fichero = new File("data\\alumnos_aleat_datos.dat");
			flujoEntrada = new RandomAccessFile(fichero, "r");
			int posicion = (codigo - 1) * Alumno.getTamagnoRegistro();
			if (posicion < 0 || posicion >= flujoEntrada.length()) {
				System.out.println("No existe ning�n alumno con c�digo " + codigo + 
				                   " en el fichero binario.");
			}
			else {
				flujoEntrada.seek(posicion);
				codigo = flujoEntrada.readInt();
				char[] vectorCaracteres = new char[Alumno.getLongitudNombre()];
				for (int i = 0 ; i < vectorCaracteres.length ; i++) {         
					vectorCaracteres[i] = flujoEntrada.readChar(); 
				}
				String nombre = new String(vectorCaracteres); 
				double nota = flujoEntrada.readDouble();
				if (codigo > 0) {
					Alumno alumno = new Alumno(codigo, nombre, nota);
					System.out.println(alumno.toString());
				}
				else {
					System.out.println("El alumno ha sido eliminado del fichero binario.");
				}
			}
		} 
		catch (FileNotFoundException fnfe) {
			System.out.println("Error al abrir el fichero:");
			System.out.println(fnfe.getMessage());
			fnfe.printStackTrace();
		}
		catch (IOException ioe) {
			System.out.println("Error al leer del fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		}
		finally {
			try {
				if (flujoEntrada != null) {
					flujoEntrada.close();
				}
			}
			catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}
		}
	}
  
}
