package libros;

public class Libro {
	
	private static int generadorCodigo = 1;
	private static final int TAMANO_REGISTRO = 220;
	private static final int LONGITUD_STRINGS = 100;
	
	//Atributos
	private int codigo;			//4 bytes
	private int codigoEscritor;	//4 bytes
	private String titulo;		//100 caracteres de 2 bytes = 200 bytes
	private int anoPublicacion;	//4 bytes
	private double precio;		//8 bytes
	
	//Constructor a partir de 4 par�metros
	public Libro(int codigoEscritor, String titulo, int anoPublicacion, double precio) {
		//Generamos c�digo autom�tico
		this.codigo = generadorCodigo;
		generadorCodigo++;
		
		this.codigoEscritor = codigoEscritor;
		
		//Colocamos con StringBuffer al titulo 100 car�cteres
		StringBuffer bufferNombre = new StringBuffer(titulo);
		bufferNombre.setLength(LONGITUD_STRINGS);
		this.titulo = bufferNombre.toString();
		
		this.anoPublicacion = anoPublicacion;
		this.precio = precio;
	}
	
	//Constructor a partir de 5 par�metros
	public Libro(int codigo, int codigoEscritor, String titulo,
			int anoPublicacion, double precio) {
		this.codigo = codigo;
		this.codigoEscritor = codigoEscritor;
		this.titulo = titulo;
		this.anoPublicacion = anoPublicacion;
		this.precio = precio;
	}
	
	//Devuelve una cadena de texto con el estado del libro
	@Override
	public String toString() {
		return "Libro [codigo = " + codigo +
				", codigo de escritor = " + codigoEscritor +
				", titulo = " + titulo.trim() +
				", a�o de publicacion = " + anoPublicacion +
				", precio = " + precio + "]";
	}
	
	public static int getGeneradorCodigo() {
		return generadorCodigo;
	}
	
	public static void setGeneradorCodigo(int generadorCodigo) {
		Libro.generadorCodigo = generadorCodigo;
	}
	
	// Devuelve el tama�o de registro del alumno.
	public static int getTamanoRegistro() {
		return TAMANO_REGISTRO;
	}
	
	// Devuelve la longitud de los Strings del objeto.
	public static int getLongitudStrings() {
		return LONGITUD_STRINGS;
	}
	
	public int getCodigo() {
		return codigo;
	}
	
	public int getCodigoEscritor() {
		return codigoEscritor;
	}
	
	public void setCodigoEscritor(int codigoEscritor) {
		this.codigoEscritor = codigoEscritor;
	}

	public String getTitulo() {
		return titulo;
	}
	
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public int getAnoPublicacion() {
		return anoPublicacion;
	}
	
	public void setAnoPublicacion(int anoPublicacion) {
		this.anoPublicacion = anoPublicacion;
	}

	public double getPrecio() {
		return precio;
	}
	
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	
}
