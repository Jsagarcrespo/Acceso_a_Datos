package libros;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collection;
import java.util.List;

import entrada.Teclado;
import escritores.AccesoEscritores;
import escritores.Escritor;

public class PrincipalLibros {

	//Visualizar el menu de opciones
	public static void escribirMenuOpciones() {
		System.out.println("\n0) Salir del programa");
		System.out.println("1) Insertar un libro en el fichero binario.");
		System.out.println("2) Consultar todos los libros del fichero binario.");
		System.out.println("3) Consultar un libro, por c�digo, del fichero binario.");
		System.out.println("4) Actualizar un libro, por c�digo, del fichero binario.");
		System.out.println("5) Eliminar un libro, por c�digo, del fichero binario.");
	}

	public static void main(String[] args) {
		File ficheroLibros = new File("data\\libros.dat");
		File ficheroEscritores = new File("data\\escritores.dat");
		int opcion, codigo, codigoEscritor, anoPublicacion;
		String titulo;
		double precio;
		Libro libro;
		List<Libro> listaLibros;
		List<Escritor> listaEscritores;

		do {
			escribirMenuOpciones();
			opcion = Teclado.leerEntero("\nSelecciona una opci�n: ");
			
			try {
				switch (opcion) {
				//Salir del programa.
				case 0:
					break;

				//Insertar un libro en el fichero binario.
				case 1:
					System.out.println("LISTADO DE ESCRITORES: ");
					listaEscritores = AccesoEscritores.leerTodos(ficheroEscritores);
					visualizarColeccionEscritores(listaEscritores);
					codigoEscritor = Teclado.leerNatural("C�digo de escritor: ");
					if (AccesoEscritores.consultarEscritor(ficheroEscritores, codigoEscritor) != null) {
						titulo = Teclado.leerCadena("T�tulo: ");
						anoPublicacion = Teclado.leerNatural("A�o de publicaci�n: ");
						precio = Teclado.leerReal("Precio: ");
						libro = new Libro(codigoEscritor, titulo, anoPublicacion, precio);
						AccesoLibros.insertarLibro(libro, ficheroLibros);
						System.out.println("Se ha insertado un libro "
											+ "en el fichero binario.");
					}
					else {
						System.out.println("No existe ning�n escritor con ese"
											+ " c�digo en el fichero binario.");
					}
					break;

				//Consultar todos los libros del fichero binario.
				case 2:
					listaLibros = AccesoLibros.leerTodos(ficheroLibros);
					visualizarColeccionLibros(listaLibros);
					break;

				//Consultar un libro, por c�digo, del fichero binario.
				case 3:
					codigo = Teclado.leerNatural("C�digo: ");
					libro = AccesoLibros.
							consultarLibro(ficheroLibros, codigo);
					if (libro == null) {
						System.out.println("No existe ning�n libro con"
										+ " ese c�digo en el fichero binario.");
					}
					else {
						System.out.println(libro.toString());
					}
					break;

				//Actualizar un libro, por c�digo, del fichero binario.
				case 4:
					codigo = Teclado.leerNatural("C�digo: ");
					codigoEscritor = Teclado.leerNatural("C�digo de escritor: ");
					titulo = Teclado.leerCadena("T�tulo: ");
					anoPublicacion = Teclado.leerNatural("A�o de publicaci�n: ");
					precio = Teclado.leerReal("Precio: ");
					libro = new Libro(codigoEscritor, titulo, anoPublicacion, precio);
					Libro.setGeneradorCodigo(Libro.getGeneradorCodigo() - 1);
					if (AccesoLibros.actualizarLibro(ficheroLibros,
							codigo, libro)) {
						System.out.println("Se ha actualizado un libro del"
										+ " fichero binario.");
					}
					else {
						System.out.println("No existe ning�n libro con"
										+ " ese codigo en el fichero binario.");
					}
					break;

				//Eliminar un libro, por c�digo, del fichero binario.
				case 5:
					codigo = Teclado.leerNatural("C�digo: ");
					if (AccesoLibros.eliminarLibro(ficheroLibros, codigo)) {
						System.out.println("Se ha eliminado un libro del"
										+ " fichero binario.");
					}
					else {
						System.out.println("No existe ning�n libro con"
										+ " ese codigo en el fichero binario.");
					}
					break;

				//Visualizar mensaje de error por no ser una opcion correcta.
				default:
					System.out.println("La opci�n debe estar entre 0 y 5.");
					break;

				}
			}
			catch (FileNotFoundException fnfe) {                      
				System.out.println("Error al abrir el fichero: " + fnfe.getMessage());
				fnfe.printStackTrace();
			}
			catch (IOException ioe) {
				System.out.println("Error al leer/escribir de/en el fichero: " + ioe.getMessage());
				ioe.printStackTrace();
			}
			
		} while (opcion != 0);
	}
	
	//Visualiza una colecci�n de escritores
	public static void visualizarColeccionEscritores(Collection<Escritor> coleccion) {
		if (coleccion.size() == 0) {
			System.out.println("El fichero binario no tiene ning�n escritor.");
		}
		else {
			for (Escritor escritor : coleccion) {
				System.out.println(escritor.toString());
			}
			System.out.println("Se han consultado " + coleccion.size()
							+ " escritores.");
		}
	}
	
	//Visualiza una colecci�n de libros
	public static void visualizarColeccionLibros(Collection<Libro> coleccion) {
		if (coleccion.size() == 0) {
			System.out.println("El fichero binario no tiene ning�n libro.");
		}
		else {
			for (Libro libro : coleccion) {
				System.out.println(libro.toString());
			}
			System.out.println("Se han consultado " + coleccion.size()
							+ " libros.");
		}
	}

}