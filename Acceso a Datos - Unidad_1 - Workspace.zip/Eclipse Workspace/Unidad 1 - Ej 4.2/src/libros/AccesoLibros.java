package libros;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;

import escritores.Escritor;

public class AccesoLibros {
	//Escribe un objeto en un fichero binario
	public static void insertarLibro(Libro libro, File fichero)
			throws IOException {
		RandomAccessFile flujoEscritura = null;
		try {
			flujoEscritura = new RandomAccessFile(fichero, "rw");
			flujoEscritura.seek(flujoEscritura.length());
			
			//Escribimos el objeto dato por dato en el fichero binario
			flujoEscritura.writeInt(libro.getCodigo());
			flujoEscritura.writeInt(libro.getCodigoEscritor());
			flujoEscritura.writeChars(libro.getTitulo());
			flujoEscritura.writeInt(libro.getAnoPublicacion());
			flujoEscritura.writeDouble(libro.getPrecio());
		}
		finally {
			if (flujoEscritura != null) {
				flujoEscritura.close();
			}
		}
	}

	//Lee los objetos de un fichero binario y la guarda en una lista de libros
	public static List<Libro> leerTodos(File fichero)
			throws FileNotFoundException, IOException {
		List<Libro> listaLibros = new ArrayList<Libro>();
		RandomAccessFile flujoLectura = null;
		try {
			Libro libro;
			int codigo, codigoEscritor, anoPublicacion;
			String titulo;
			double precio;
			flujoLectura = new RandomAccessFile(fichero, "r");
			flujoLectura.seek(0);			
			while (flujoLectura.getFilePointer() < flujoLectura.length()) {
				//Obtenemos el c�digo del libro
				codigo = flujoLectura.readInt();
				
				//Si el c�digo es mayor que 0, no estar� eliminado
				if (codigo > 0) {
					//Obtenemos el c�digo de escritor del libro
					codigoEscritor = flujoLectura.readInt();
					
					//Obtenemos el titulo del libro
					char[] vectorTitulo = new char[Libro.getLongitudStrings()];
					for (int i = 0 ; i < vectorTitulo.length ; i++) {         
						vectorTitulo[i] = flujoLectura.readChar(); 
					}
					titulo = new String(vectorTitulo);
					
					//Obtenemos el a�o de publicacion del libro
					anoPublicacion = flujoLectura.readInt();
					
					//Obtenemos el precio del libro
					precio = flujoLectura.readDouble();
					
					libro = new Libro(codigo, codigoEscritor, titulo, anoPublicacion, precio);
					listaLibros.add(libro);
				}
				else {
					flujoLectura.seek(flujoLectura.getFilePointer() +
										Escritor.getTamanoRegistro() - 4);
				}
			}
		}
		finally {
			if (flujoLectura != null) {
				flujoLectura.close();
			}
		}

		return listaLibros;
	}
	
	//Consulta un libro a partir de un codigo en el fichero binario
	public static Libro consultarLibro(File fichero, int codigo) 
			throws FileNotFoundException, IOException {
		RandomAccessFile flujoLectura = null;
		Libro libro = null;
		try {
			flujoLectura = new RandomAccessFile(fichero, "r");
			int posicion = (codigo - 1) * Libro.getTamanoRegistro();
			if (posicion >= 0 && posicion < flujoLectura.length()) {
				flujoLectura.seek(posicion);
				
				//Obtenemos el c�digo del libro
				codigo = flujoLectura.readInt();
				
				//Si el c�digo es mayor que 0, no estar� eliminado
				if (codigo > 0) {
					//Obtenemos el c�digo de escritor del libro
					int codigoEscritor = flujoLectura.readInt();
					
					//Obtenemos el titulo del libro
					char[] vectorTitulo = new char[Libro.getLongitudStrings()];
					for (int i = 0 ; i < vectorTitulo.length ; i++) {         
						vectorTitulo[i] = flujoLectura.readChar(); 
					}
					String titulo = new String(vectorTitulo);
					
					//Obtenemos el a�o de publicacion del libro
					int anoPublicacion = flujoLectura.readInt();
					
					//Obtenemos el precio del libro
					double precio = flujoLectura.readDouble();
					
					libro = new Libro(codigo, codigoEscritor, titulo, anoPublicacion, precio);
				}
				else {
					flujoLectura.seek(flujoLectura.getFilePointer() +
										Escritor.getTamanoRegistro() - 4);
				}
			}
			return libro;
		}
		finally {
			if (flujoLectura != null) {
				flujoLectura.close();
			}
		}
	}

	//Actualiza el libro a partir de un codigo en el fichero binario
	public static boolean actualizarLibro(File fichero, int codigo, Libro libro)
			throws FileNotFoundException, IOException {
		RandomAccessFile flujoEscritura = null;
		boolean encontrado = false;
		try {
			flujoEscritura = new RandomAccessFile(fichero, "rw");
			int posicion = (codigo - 1) * Libro.getTamanoRegistro();
			if (posicion > 0 && posicion < flujoEscritura.length()) {
				flujoEscritura.seek(posicion);
				
				int codigoEnFichero = flujoEscritura.readInt();
				if (codigo == codigoEnFichero) {
					encontrado = true;
					
					//Sustituimos el objeto dato por dato en el fichero binario
					flujoEscritura.writeInt(libro.getCodigoEscritor());
					flujoEscritura.writeChars(libro.getTitulo());
					flujoEscritura.writeInt(libro.getAnoPublicacion());
					flujoEscritura.writeDouble(libro.getPrecio());
				}
			}
		}
		finally {
			if (flujoEscritura != null) {
				flujoEscritura.close();
			}
		}

		return encontrado;

	}

	//Elimina un libro a partir de un codigo en el fichero binario
	public static boolean eliminarLibro(File fichero, int codigo) 
			throws FileNotFoundException, IOException {
		RandomAccessFile flujoEscritura = null;
		boolean encontrado = false;
		try {
			flujoEscritura = new RandomAccessFile(fichero, "rw");
			int posicion = (codigo - 1) * Libro.getTamanoRegistro();
			if (posicion >= 0 && posicion < flujoEscritura.length()) {
				encontrado = true;
				flujoEscritura.seek(posicion);
				
				//Modificamos el c�digo del libro
				flujoEscritura.writeInt(0);
			}
		}
		finally {
			if (flujoEscritura != null) {
				flujoEscritura.close();
			}
		}

		return encontrado;

	}

}
