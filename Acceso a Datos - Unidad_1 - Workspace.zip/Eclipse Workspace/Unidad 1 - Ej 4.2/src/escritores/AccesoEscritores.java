package escritores;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;

public class AccesoEscritores {
	//Lee los objetos de un fichero binario y la guarda en una lista de escritores
	public static List<Escritor> leerTodos(File fichero)
			throws FileNotFoundException, IOException {
		List<Escritor> listaEscritores = new ArrayList<Escritor>();
		RandomAccessFile flujoLectura = null;
		try {
			Escritor escritor;
			int codigo;
			String nombre, fechaNacimiento, nacionalidad;
			flujoLectura = new RandomAccessFile(fichero, "r");
			flujoLectura.seek(0);			
			while (flujoLectura.getFilePointer() < flujoLectura.length()) {
				//Obtenemos el c�digo del escritor
				codigo = flujoLectura.readInt();
				
				//Si el c�digo es mayor que 0, no estar� eliminado
				if (codigo > 0) {
					//Obtenemos el nombre del escritor
					char[] vectorNombre = new char[Escritor.getLongitudStrings()];
					for (int i = 0 ; i < vectorNombre.length ; i++) {         
						vectorNombre[i] = flujoLectura.readChar(); 
					}
					nombre = new String(vectorNombre);
					
					//Obtenemos la fecha de nacimiento del escritor
					char[] vectorFecha = new char[Escritor.getLongitudFecha()];
					for (int i = 0 ; i < vectorFecha.length ; i++) {         
						vectorFecha[i] = flujoLectura.readChar(); 
					}
					fechaNacimiento = new String(vectorFecha);
					
					//Obtenemos el nombre del escritor
					char[] vectorNacionalidad = new char[Escritor.getLongitudStrings()];
					for (int i = 0 ; i < vectorNacionalidad.length ; i++) {         
						vectorNacionalidad[i] = flujoLectura.readChar(); 
					}
					nacionalidad = new String(vectorNacionalidad);
					
					escritor = new Escritor(codigo, nombre, fechaNacimiento, nacionalidad);
					listaEscritores.add(escritor);
				}
				else {
					flujoLectura.seek(flujoLectura.getFilePointer() +
										Escritor.getTamanoRegistro() - 4);
				}
			}
		}
		finally {
			if (flujoLectura != null) {
				flujoLectura.close();
			}
		}

		return listaEscritores;
	}
	
	//Consulta un escritor a partir de un codigo en el fichero binario
	public static Escritor consultarEscritor(File fichero, int codigo) 
			throws FileNotFoundException, IOException {
		RandomAccessFile flujoLectura = null;
		Escritor escritor = null;
		try {
			flujoLectura = new RandomAccessFile(fichero, "r");
			int posicion = (codigo - 1) * Escritor.getTamanoRegistro();
			if (posicion >= 0 && posicion < flujoLectura.length()) {
				flujoLectura.seek(posicion);
				
				//Obtenemos el c�digo del escritor
				codigo = flujoLectura.readInt();
				
				//Si el c�digo es mayor que 0, no estar� eliminado
				if (codigo > 0) {
					//Obtenemos el nombre del escritor
					char[] vectorNombre = new char[Escritor.getLongitudStrings()];
					for (int i = 0 ; i < vectorNombre.length ; i++) {         
						vectorNombre[i] = flujoLectura.readChar(); 
					}
					String nombre = new String(vectorNombre);
					
					//Obtenemos la fecha de nacimiento del escritor
					char[] vectorFecha = new char[Escritor.getLongitudFecha()];
					for (int i = 0 ; i < vectorFecha.length ; i++) {         
						vectorFecha[i] = flujoLectura.readChar(); 
					}
					String fechaNacimiento = new String(vectorFecha);
					
					//Obtenemos el nombre del escritor
					char[] vectorNacionalidad = new char[Escritor.getLongitudStrings()];
					for (int i = 0 ; i < vectorNacionalidad.length ; i++) {         
						vectorNacionalidad[i] = flujoLectura.readChar(); 
					}
					String nacionalidad = new String(vectorNacionalidad);
					
					escritor = new Escritor(codigo, nombre, fechaNacimiento, nacionalidad);
				}
				else {
					flujoLectura.seek(flujoLectura.getFilePointer() +
										Escritor.getTamanoRegistro() - 4);
				}
			}
			return escritor;
		}
		finally {
			if (flujoLectura != null) {
				flujoLectura.close();
			}
		}
	}

}
