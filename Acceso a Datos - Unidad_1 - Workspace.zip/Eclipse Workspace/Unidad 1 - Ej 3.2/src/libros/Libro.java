package libros;

import java.io.Serializable;

public class Libro implements Serializable {
	
	//N�mero de versi�n de la clase
	//Verifica que el escritor y el lector del libro serializado son compatibles.
	private static final long serialVersionUID = 1L;
	
	//Atributos
	private int codigo;
	private int codigoEscritor;
	private String titulo;
	private int anoPublicacion;
	private double precio;
	
	//Constructor a partir de par�metros
	public Libro(int codigo, int codigoEscritor, String titulo,
			int anoPublicacion, double precio) {
		this.codigo = codigo;
		this.codigoEscritor = codigoEscritor;
		this.titulo = titulo;
		this.anoPublicacion = anoPublicacion;
		this.precio = precio;
	}
	
	//Devuelve una cadena de texto con el estado del libro
	@Override
	public String toString() {
		return "Libro [codigo = " + codigo +
				", codigo de escritor = " + codigoEscritor +
				", titulo = " + titulo +
				", a�o de publicacion = " + anoPublicacion +
				", precio = " + precio + "]";
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigoEscritor(int codigoEscritor) {
		this.codigoEscritor = codigoEscritor;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public void setAnoPublicacion(int anoPublicacion) {
		this.anoPublicacion = anoPublicacion;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}
	
}
