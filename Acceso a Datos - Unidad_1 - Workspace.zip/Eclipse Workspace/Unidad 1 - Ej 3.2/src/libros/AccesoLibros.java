package libros;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;
import java.util.ArrayList;
import java.util.List;

public class AccesoLibros {
	//Escribe un objeto en un fichero binario
	public static void insertarLibro(Libro libro, File fichero)
			throws IOException {
		ObjectOutputStream flujoEscritura1 = null;
		MyObjectOutputStream flujoEscritura2 = null;
		try {
			//Insertar el libro al final del fichero.
			if (fichero.exists()) {
				flujoEscritura2 = new MyObjectOutputStream(new FileOutputStream(fichero, true));
				flujoEscritura2.writeObject(libro);
			}
			//Crear el fichero e insertar el libro al principio del fichero.
			else {
				flujoEscritura1 = new ObjectOutputStream(new FileOutputStream(fichero));
				flujoEscritura1.writeObject(libro);
			}
		}
		finally {
			if (flujoEscritura1 != null) {
				flujoEscritura1.close();
			}
			if (flujoEscritura2 != null) {
				flujoEscritura2.close();
			}
		}
	}

	//Lee los objetos de un fichero binario y la guarda en una lista de libros
	public static List<Libro> leerTodos(File fichero)
			throws FileNotFoundException, IOException, ClassNotFoundException {
		List<Libro> listaLibros = new ArrayList<Libro>();
		ObjectInputStream flujoLectura = null;
		try {
			if (fichero.exists()) {
				Libro libro;
				flujoLectura = new ObjectInputStream(new FileInputStream(fichero));
				try {
					while (true) {
						libro = (Libro) flujoLectura.readObject();
						listaLibros.add(libro);
					}
				}
				catch (EOFException eofe) {
					System.out.println("Se ha alcanzado el final del fichero binario.");
				}
				catch (StreamCorruptedException sce) {
					System.out.println("Se ha encontrado informaci�n inconsistente en el fichero binario.");
				}
			}
		}
		finally {
			if (flujoLectura != null) {
				flujoLectura.close();
			}
		}

		return listaLibros;
	}

	

	//Consulta un libro a partir de un codigo en el fichero binario
	public static Libro consultarLibro(File fichero, int codigo) 
			throws FileNotFoundException, IOException, ClassNotFoundException {
		ObjectInputStream flujoLectura = null;
		Libro libro = null;
		try {
			if (fichero.exists()) {
				flujoLectura = new ObjectInputStream(new FileInputStream(fichero));
				boolean encontrado = false;
				try {
					while (true && ! encontrado) {
						libro = (Libro) flujoLectura.readObject();
						if (libro.getCodigo() == codigo) {
							encontrado = true;
						}
					}
				}
				catch (EOFException eofe) {
					System.out.println("Se ha alcanzado el final del fichero binario.");
				}
				catch (StreamCorruptedException sce) {
					System.out.println("Se ha encontrado informaci�n inconsistente en el fichero binario.");
				}

				if (! encontrado) {
					libro = null;
				}
			}
		}
		finally {
			if (flujoLectura != null) {
				flujoLectura.close();
			}
		}
		return libro;
	}

	//Actualiza el libro a partir de un codigo en el fichero binario
	public static boolean actualizarLibro(File fichero, int codigo, int codigoEscritor,
			String titulo, int anoPublicacion, double precio)
			throws FileNotFoundException, IOException, ClassNotFoundException {
		List<Libro> listaLibros = leerTodos(fichero);
		boolean encontrado = false;
		int posicionActualizar = 0;
		Libro libro;
		for (int i = 0; i < listaLibros.size() && !encontrado; i++) {
			libro = listaLibros.get(i);
			if (libro.getCodigo() == codigo) {
				encontrado = true;
				posicionActualizar = i;
			}
		}
		if (encontrado) {
			libro = listaLibros.get(posicionActualizar);
			libro.setCodigoEscritor(codigoEscritor);
			libro.setTitulo(titulo);
			libro.setAnoPublicacion(anoPublicacion);
			libro.setPrecio(precio);
			escribirTodos(listaLibros, fichero);
		}

		return encontrado;

	}

	//Elimina un libro a partir de un codigo en el fichero binario
	public static boolean eliminarLibro(File fichero, int codigo) 
			throws FileNotFoundException, IOException, ClassNotFoundException {
		List<Libro> listaLibros = leerTodos(fichero);
		boolean encontrado = false;
		int posicionEliminar = 0;
		Libro libro;
		for (int i = 0; i < listaLibros.size() && !encontrado; i++) {
			libro = listaLibros.get(i);
			if (libro.getCodigo() == codigo) {
				encontrado = true;
				posicionEliminar = i;
			}
		}
		if (encontrado) {
			listaLibros.remove(posicionEliminar);
			escribirTodos(listaLibros, fichero);
		}

		return encontrado;

	}

	//Guarda cada elemento de una lista de libros en un fichero binario
	public static void escribirTodos(List<Libro> listaLibros,
			File fichero) throws IOException {
		ObjectOutputStream flujoEscritura = null;
		try {
			Libro libro;
			//Crear el fichero e insertar el libro al principio del fichero.
			flujoEscritura = new ObjectOutputStream(new FileOutputStream(fichero));
			for (int i = 0; i < listaLibros.size(); i++) {
				libro = listaLibros.get(i);
				flujoEscritura.writeObject(libro);
			}
		}
		finally {
			if (flujoEscritura != null) {
				flujoEscritura.close();
			}
		}

	}

}
