package escritores;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.StreamCorruptedException;
import java.util.ArrayList;
import java.util.List;

public class AccesoEscritores {
	//Consulta un escritor a partir de un codigo en el fichero binario
	public static Escritor consultarEscritor(File fichero, int codigo) 
			throws FileNotFoundException, IOException, ClassNotFoundException {
		ObjectInputStream flujoLectura = null;
		Escritor escritor = null;
		try {
			if (fichero.exists()) {
				flujoLectura = new ObjectInputStream(new FileInputStream(fichero));
				boolean encontrado = false;
				try {
					while (true && ! encontrado) {
						escritor = (Escritor) flujoLectura.readObject();
						if (escritor.getCodigo() == codigo) {
							encontrado = true;
						}
					}
				}
				catch (EOFException eofe) {
					System.out.println("Se ha alcanzado el final del fichero binario.");
				}
				catch (StreamCorruptedException sce) {
					System.out.println("Se ha encontrado informaci�n inconsistente en el fichero binario.");
				}

				if (! encontrado) {
					escritor = null;
				}
			}
		}
		finally {
			if (flujoLectura != null) {
				flujoLectura.close();
			}
		}
		return escritor;
	}
	
	//Lee los objetos de un fichero binario y la guarda en una lista de escritores
	public static List<Escritor> leerTodos(File fichero)
			throws FileNotFoundException, IOException, ClassNotFoundException {
		List<Escritor> listaEscritores = new ArrayList<Escritor>();
		ObjectInputStream flujoLectura = null;
		try {
			if (fichero.exists()) {
				Escritor escritor;
				flujoLectura = new ObjectInputStream(new FileInputStream(fichero));
				try {
					while (true) {
						escritor = (Escritor) flujoLectura.readObject();
						listaEscritores.add(escritor);
					}
				}
				catch (EOFException eofe) {
					System.out.println("Se ha alcanzado el final del fichero binario.");
				}
				catch (StreamCorruptedException sce) {
					System.out.println("Se ha encontrado informaci�n inconsistente en el fichero binario.");
				}
			}
		}
		finally {
			if (flujoLectura != null) {
				flujoLectura.close();
			}
		}

		return listaEscritores;
	}
}
