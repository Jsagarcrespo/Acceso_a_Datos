package acceso_ficheros;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import entrada.Teclado;

public class PrincipalFicheros {
	//Visualizar el menu de opciones
	public static void escribirMenuOpciones() {
		System.out.println("\n0) Salir del programa");
		System.out.println("1) Escribir varias frases en el fichero de texto.");
		System.out.println("2) Leer todas las frases del fichero de texto.");
		System.out.println("3) Consultar el numero de lineas y el numero de palabras"
				+ " del fichero de texto.");
		System.out.println("4) Buscar una palabra en el fichero de texto.");
		System.out.println("5) Crear otro fichero de texto con las frases del fichero"
				+ " de texto convertidas a mayusculas.");
		System.out.println("6) Crear otro fichero de texto con las frases del fichero"
				+ " de texto convertidas a minusculas.");
	}

	public static void main(String[] args) {
		try {
			File ficheroFrases = new File("data\\frases.txt");
			if (!ficheroFrases.exists()) {
				System.out.println("El archivo no existe.");
			}
			else if(!ficheroFrases.isFile()) {
				System.out.println("El archivo no es un fichero");
			}
			else {
				int opcion, numLinea;
				String frase = "", palabra = "";
				int[] estadisticas;
				List<String> listaLineas;
				List<String> listaLineasModificadas;
				File ficheroSalida;

				do {
					escribirMenuOpciones();

					opcion = Teclado.leerEntero("\nSelecciona una opcion: ");

					switch (opcion) {
					//Salir del programa.
					case 0:
						break;
						
					//Escribir varias frases en el fichero de texto.
					case 1:
						while (! frase.equals("***")) {
							frase = Teclado.leerCadena("Frase (*** para salir): ");
							if (! frase.equals("***")) {
								AccesoFicheros.introducirLinea(frase, ficheroFrases);
								System.out.println("Se ha escrito la frase en el fichero.");
							}
						}
						break;
						
					//Leer todas las frases del fichero de texto.
					case 2:
						AccesoFicheros.mostrarFichero(ficheroFrases);
						break;

					//Consultar el numero de lineas y el numero
					//de palabras del fichero de texto.
					case 3:
						estadisticas = AccesoFicheros.consultarLineasPalabras(ficheroFrases);
						System.out.println("El fichero tiene " + 
											estadisticas[0] + " lineas y " +
											estadisticas[1] + " palabras.");
						break;
						
					//Buscar una palabra en el fichero de texto.
					case 4:
						palabra = Teclado.leerCadena("Palabra: ");
						while (palabra.contains(" ")) {
							System.out.println("La cadena introducida no"
												+ " es una palabra");
							palabra = Teclado.leerCadena("Palabra: ");
						}
						
						numLinea = AccesoFicheros.
									buscarPalabra(palabra, ficheroFrases);
						if (numLinea != 0) {
							System.out.println("La palabra est� en la l�nea "
									+ numLinea + " del fichero de texto.");
						}
						else {
							System.out.println("La palabra no esta en el "
												+ "fichero de texto.");
						}
						break;
						
					//Crear otro fichero de texto con las frases del
					//fichero de texto convertidas a mayusculas.
					case 5:
						ficheroSalida = new File("data\\mayusculas.txt");
						listaLineas = AccesoFicheros.guardarFichero(ficheroFrases);
						listaLineasModificadas = AccesoFicheros.
								transformarMinusculasMayusculas(listaLineas, true);
						AccesoFicheros.escribirTodas(listaLineasModificadas, ficheroSalida);
						
						System.out.println("Se han escrito las l�neas en may�sculas"
											+ "en el nuevo fichero con �xito.");
						break;
						
					//Crear otro fichero de texto con las frases del
					//fichero de texto convertidas a minusculas.
					case 6:
						ficheroSalida = new File("data\\minusculas.txt");
						listaLineas = AccesoFicheros.guardarFichero(ficheroFrases);
						listaLineasModificadas = AccesoFicheros.
								transformarMinusculasMayusculas(listaLineas, false);
						AccesoFicheros.escribirTodas(listaLineasModificadas, ficheroSalida);
						
						System.out.println("Se han escrito las l�neas en min�sculas"
											+ "en el nuevo fichero con �xito.");
						break;
						
						//Visualizar mensaje de error por no ser una opcion correcta.
					default:
						System.out.println("La opcion debe estar entre 0 y 6");
						break;
						
					}

				} while (opcion != 0);
			}

		}
		catch (FileNotFoundException fnfe) {                      
			System.out.println("Error al abrir el fichero: " + fnfe.getMessage());
			fnfe.printStackTrace();
		}
		catch (IOException ioe) {
			System.out.println("Error al leer/escribir de/en el fichero: " + ioe.getMessage());
			ioe.printStackTrace();
		}
	}
}
