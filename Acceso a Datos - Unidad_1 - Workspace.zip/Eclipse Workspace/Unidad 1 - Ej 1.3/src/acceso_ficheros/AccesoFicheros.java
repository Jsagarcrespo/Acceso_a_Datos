package acceso_ficheros;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AccesoFicheros {

	//Escribe una linea en un fichero de texto
	public static void introducirLinea(String linea, File fichero) 
			throws IOException {
		BufferedWriter flujoEscritura = null;
		try {
			flujoEscritura = new BufferedWriter(new FileWriter(fichero, true));
			flujoEscritura.write(linea);
			flujoEscritura.newLine();
		}
		finally {
			if (flujoEscritura != null) {
				flujoEscritura.close();
			}
		}
	}

	//Muestra las lineas de un fichero de texto por consola
	public static void mostrarFichero(File fichero)
			throws FileNotFoundException, IOException {
		BufferedReader flujoLectura = null;
		try {
			flujoLectura = new BufferedReader(new FileReader(fichero));
			String linea = flujoLectura.readLine(); 
			while (linea != null) { 	 
				System.out.println(linea);
				linea = flujoLectura.readLine();
			}
		}
		finally {
			if (flujoLectura != null) {
				flujoLectura.close();
			}
		}
	}

	//Calcula el numero de lineas y palabras de un fichero de texto
	public static int[] consultarLineasPalabras(File fichero)
			throws FileNotFoundException, IOException {
		BufferedReader flujoLectura = null;
		int[] numLineasPalabras = new int[2];

		try {
			int numLineas = 0;
			int numPalabras = 0;

			flujoLectura = new BufferedReader(new FileReader(fichero));
			String linea = flujoLectura.readLine(); 
			while (linea != null) {
				numLineas++;
				numPalabras += contarPalabras(linea);
				linea = flujoLectura.readLine(); 
			}

			numLineasPalabras[0] = numLineas;
			numLineasPalabras[1] = numPalabras;
		}
		finally {
			if (flujoLectura != null) {
				flujoLectura.close();
			}
		}

		return numLineasPalabras;
	}

	//Cuenta el numero de espacios separando palabras que hay
	public static int contarPalabras(String frase) {
		frase = frase.trim();
		String[] palabras = frase.split("[ ]+"); //uno o mas espacios en blanco
		return palabras.length;
	}

	//Busca una palabra en un fichero de texto
	//y devuelve la l�nea en la que se encuentra
	public static int buscarPalabra(String palabra, File fichero)
			throws FileNotFoundException, IOException {
		BufferedReader flujoLectura = null;
		int numLinea = 0;
		boolean encontrada = false;

		try {
			flujoLectura = new BufferedReader(new FileReader(fichero));
			String linea = flujoLectura.readLine();
			while (linea != null && !encontrada) {
				numLinea++;
				if (linea.contains(palabra)) {
					encontrada = true;
				}
				linea = flujoLectura.readLine();
			}

			if (!encontrada) {
				numLinea = 0;
			}
		}
		finally {
			if (flujoLectura != null) {
				flujoLectura.close();
			}
		}

		return numLinea;
	}

	//Guarda las lineas de un fichero de texto en una lista de strings
	public static List<String> guardarFichero(File fichero)
			throws FileNotFoundException, IOException {
		List<String> lista = new ArrayList<String>();
		BufferedReader flujoLectura = null;
		try {
			flujoLectura = new BufferedReader(new FileReader(fichero));
			String linea = flujoLectura.readLine(); 
			while (linea != null) { 	 
				lista.add(linea);
				linea = flujoLectura.readLine();
			}
		}
		finally {
			if (flujoLectura != null) {
				flujoLectura.close();
			}
		}

		return lista;
	}
	
	//Guarda cada elemento de una lista de strings en un fichero
	public static void escribirTodas(List<String> listaResultados,
									File ficheroSalida) throws IOException {
		BufferedWriter flujoEscritura = null;
		try {
			flujoEscritura = new BufferedWriter(new FileWriter(ficheroSalida, false));
			String linea;
			for (int i = 0; i < listaResultados.size(); i++) {
				linea = listaResultados.get(i);
				flujoEscritura.write(linea);
				flujoEscritura.newLine();
			}
		}
		finally {
			if (flujoEscritura != null) {
				flujoEscritura.close();
			}
		}
	}
	

	//Modifica cada elemento de una lista de strings a minusculas o mayusculas
	//y devuelve otra lista con la transformacion
	//Si el parametro booleano tipo es true se convertira a mayusculas
	//y si es false a minusculas
	public static List<String> transformarMinusculasMayusculas(List<String> lista,
			boolean tipo) {
		List<String> listaModificada = new ArrayList<String>();
		
		for (String linea : lista) {
			if (tipo) {
				listaModificada.add(linea.toUpperCase());
			}
			else {
				listaModificada.add(linea.toLowerCase());
			}
		}
		
		return listaModificada;
	}
}
