package escritores;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;
import java.util.ArrayList;
import java.util.List;

public class AccesoEscritores {
	//Escribe un objeto en un fichero binario
	public static void insertarEscritor(Escritor escritor, File fichero)
			throws IOException {
		ObjectOutputStream flujoEscritura1 = null;
		MyObjectOutputStream flujoEscritura2 = null;
		try {
			//Insertar el escritor al final del fichero.
			if (fichero.exists()) {
				flujoEscritura2 = new MyObjectOutputStream(new FileOutputStream(fichero, true));
				flujoEscritura2.writeObject(escritor);
			}
			//Crear el fichero e insertar el escritor al principio del fichero.
			else {
				flujoEscritura1 = new ObjectOutputStream(new FileOutputStream(fichero));
				flujoEscritura1.writeObject(escritor);
			}
		}
		finally {
			if (flujoEscritura1 != null) {
				flujoEscritura1.close();
			}
			if (flujoEscritura2 != null) {
				flujoEscritura2.close();
			}
		}
	}

	//Lee los objetos de un fichero binario y la guarda en una lista de escritores
	public static List<Escritor> leerTodos(File fichero)
			throws FileNotFoundException, IOException, ClassNotFoundException {
		List<Escritor> listaEscritores = new ArrayList<Escritor>();
		ObjectInputStream flujoLectura = null;
		try {
			if (fichero.exists()) {
				Escritor escritor;
				flujoLectura = new ObjectInputStream(new FileInputStream(fichero));
				try {
					while (true) {
						escritor = (Escritor) flujoLectura.readObject();
						listaEscritores.add(escritor);
					}
				}
				catch (EOFException eofe) {
					System.out.println("Se ha alcanzado el final del fichero binario.");
				}
				catch (StreamCorruptedException sce) {
					System.out.println("Se ha encontrado informaci�n inconsistente en el fichero binario.");
				}
			}
		}
		finally {
			if (flujoLectura != null) {
				flujoLectura.close();
			}
		}

		return listaEscritores;
	}
	
	//Consulta un escritor a partir de un codigo en el fichero binario
	public static Escritor consultarEscritor(File fichero, int codigo) 
			throws FileNotFoundException, IOException, ClassNotFoundException {
		ObjectInputStream flujoLectura = null;
		Escritor escritor = null;
		try {
			if (fichero.exists()) {
				flujoLectura = new ObjectInputStream(new FileInputStream(fichero));
				boolean encontrado = false;
				try {
					while (true && ! encontrado) {
						escritor = (Escritor) flujoLectura.readObject();
						if (escritor.getCodigo() == codigo) {
							encontrado = true;
						}
					}
				}
				catch (EOFException eofe) {
					System.out.println("Se ha alcanzado el final del fichero binario.");
				}
				catch (StreamCorruptedException sce) {
					System.out.println("Se ha encontrado informaci�n inconsistente en el fichero binario.");
				}
				
				if (! encontrado) {
					escritor = null;
				}
			}
		}
		finally {
			if (flujoLectura != null) {
				flujoLectura.close();
			}
		}
		return escritor;
	}
	
	//Actualiza el escritor a partir de un codigo en el fichero binario
	public static boolean actualizarEscritor(File fichero, int codigo,
			String nombre, String fechaNacimiento, String nacionalidad)
			throws FileNotFoundException, IOException, ClassNotFoundException {
		List<Escritor> listaEscritores = leerTodos(fichero);
		boolean encontrado = false;
		int posicionActualizar = 0;
		Escritor escritor;
		for (int i = 0; i < listaEscritores.size() && !encontrado; i++) {
			escritor = listaEscritores.get(i);
			if (escritor.getCodigo() == codigo) {
				encontrado = true;
				posicionActualizar = i;
			}
		}
		if (encontrado) {
			escritor = listaEscritores.get(posicionActualizar);
			escritor.setNombre(nombre);
			escritor.setFechaNacimiento(fechaNacimiento);
			escritor.setNacionalidad(nacionalidad);
			escribirTodos(listaEscritores, fichero);
		}

		return encontrado;

	}

	//Elimina un escritor a partir de un codigo en el fichero binario
	public static boolean eliminarEscritor(File fichero, int codigo) 
			throws FileNotFoundException, IOException, ClassNotFoundException {
		List<Escritor> listaEscritores = leerTodos(fichero);
		boolean encontrado = false;
		int posicionEliminar = 0;
		Escritor escritor;
		for (int i = 0; i < listaEscritores.size() && !encontrado; i++) {
			escritor = listaEscritores.get(i);
			if (escritor.getCodigo() == codigo) {
				encontrado = true;
				posicionEliminar = i;
			}
		}
		if (encontrado) {
			listaEscritores.remove(posicionEliminar);
			escribirTodos(listaEscritores, fichero);
		}

		return encontrado;

	}

	//Guarda cada elemento de una lista de escritores en un fichero binario
	public static void escribirTodos(List<Escritor> listaEscritores,
			File fichero) throws IOException {
		ObjectOutputStream flujoEscritura = null;
		try {
			Escritor escritor;
			//Crear el fichero e insertar el escritor al principio del fichero.
			flujoEscritura = new ObjectOutputStream(new FileOutputStream(fichero));
			for (int i = 0; i < listaEscritores.size(); i++) {
				escritor = listaEscritores.get(i);
				flujoEscritura.writeObject(escritor);
			}
		}
		finally {
			if (flujoEscritura != null) {
				flujoEscritura.close();
			}
		}

	}

}
