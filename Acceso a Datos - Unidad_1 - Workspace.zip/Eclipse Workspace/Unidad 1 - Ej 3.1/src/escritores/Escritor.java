package escritores;

import java.io.Serializable;

public class Escritor implements Serializable {
	
	//N�mero de versi�n de la clase
	//Verifica que el escritor y el lector del escritor serializado son compatibles.
	private static final long serialVersionUID = 1L;
	
	//Atributos
	private int codigo;
	private String nombre;
	private String fechaNacimiento;
	private String nacionalidad;
	
	//Constructor a partir de par�metros
	public Escritor(int codigo, String nombre, String fechaNacimiento, String nacionalidad) {
		this.codigo = codigo;
		this.nombre = nombre;
		this.fechaNacimiento = fechaNacimiento;
		this.nacionalidad = nacionalidad;
	}
	
	//Devuelve una cadena de texto con el estado del escritor
	@Override
	public String toString() {
		return "Escritor [codigo = " + codigo +
				", nombre = " + nombre +
				", fecha de nacimiento = " + fechaNacimiento +
				", nacionalidad = " + nacionalidad + "]";
	}
	
	public int getCodigo() {
		return codigo;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public void setFechaNacimiento(String fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}
	
	public void setNacionalidad(String nacionalidad) {
		this.nacionalidad = nacionalidad;
	}
	
}
