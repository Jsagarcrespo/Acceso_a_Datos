package escritores;

public class Escritor {
	
	private static int generadorCodigo = 1;
	private static final int TAMANO_REGISTRO = 144;
	private static final int LONGITUD_STRINGS = 30;
	private static final int LONGITUD_FECHA = 10;
	
	//Atributos
	private int codigo;				//4 bytes
	private String nombre;			//30 caracteres de 2 bytes = 60 bytes
	private String fechaNacimiento;	//10 caracteres de 2 bytes = 20 bytes
	private String nacionalidad;	//30 caracteres de 2 bytes = 60 bytes
	
	//Constructor a partir de 3 par�metros
	public Escritor(String nombre, String fechaNacimiento, String nacionalidad) {
		//Generamos c�digo autom�tico
		this.codigo = generadorCodigo;
		generadorCodigo++;
		
		//Colocamos con StringBuffer al nombre 30 car�cteres
		StringBuffer bufferNombre = new StringBuffer(nombre);
		bufferNombre.setLength(LONGITUD_STRINGS);
		this.nombre = bufferNombre.toString();
		
		//Colocamos con StringBuffer a la fecha de nacimiento 10 car�cteres
		StringBuffer bufferFechaNac = new StringBuffer(fechaNacimiento);
		bufferFechaNac.setLength(LONGITUD_FECHA);
		this.fechaNacimiento = bufferFechaNac.toString();
		
		//Colocamos con StringBuffer al nacionalidad 30 car�cteres
		StringBuffer bufferNacionalidad = new StringBuffer(nacionalidad);
		bufferNacionalidad.setLength(LONGITUD_STRINGS);
		this.nacionalidad = bufferNacionalidad.toString();
	}
	
	//Constructor a partir de 4 par�metros
	public Escritor(int codigo, String nombre, String fechaNacimiento, String nacionalidad) {
		this.codigo = codigo;
		this.nombre = nombre;
		this.fechaNacimiento = fechaNacimiento;
		this.nacionalidad = nacionalidad;
	}

	//Devuelve una cadena de texto con el estado del escritor
	@Override
	public String toString() {
		return "Escritor [codigo = " + codigo +
				", nombre = " + nombre.trim() +
				", fecha de nacimiento = " + fechaNacimiento.trim() +
				", nacionalidad = " + nacionalidad.trim() + "]";
	}
	
	public static int getGeneradorCodigo() {
		return generadorCodigo;
	}

	public static void setGeneradorCodigo(int generadorCodigo) {
		Escritor.generadorCodigo = generadorCodigo;
	}

	// Devuelve el tama�o de registro del alumno.
	public static int getTamanoRegistro() {
		return TAMANO_REGISTRO;
	}
	
	// Devuelve la longitud de los Strings del objeto.
	public static int getLongitudStrings() {
		return LONGITUD_STRINGS;
	}
	
	// Devuelve la longitud de la fecha de nacimiento del objeto.
	public static int getLongitudFecha() {
		return LONGITUD_FECHA;
	}
	
	public int getCodigo() {
		return codigo;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public String getFechaNacimiento() {
		return fechaNacimiento;
	}
	
	public void setFechaNacimiento(String fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}
	
	public String getNacionalidad() {
		return nacionalidad;
	}
	
	public void setNacionalidad(String nacionalidad) {
		this.nacionalidad = nacionalidad;
	}
	
}
