package escritores;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collection;
import java.util.List;

import entrada.Teclado;

public class PrincipalEscritores {

	//Visualizar el menu de opciones
	public static void escribirMenuOpciones() {
		System.out.println("\n0) Salir del programa");
		System.out.println("1) Insertar un escritor en el fichero binario.");
		System.out.println("2) Consultar todos los escritores del fichero binario.");
		System.out.println("3) Consultar un escritor, por c�digo, del fichero binario.");
		System.out.println("4) Actualizar un escritor, por c�digo, del fichero binario.");
		System.out.println("5) Eliminar un escritor, por c�digo, del fichero binario.");
	}

	public static void main(String[] args) {
		File ficheroEscritores = new File("data\\escritores.dat");
		int opcion, codigo;
		String nombre, fechaNacimiento, nacionalidad;
		Escritor escritor;
		List<Escritor> listaEscritores;

		do {
			escribirMenuOpciones();
			opcion = Teclado.leerEntero("\nSelecciona una opci�n: ");
			
			try {
				switch (opcion) {
				//Salir del programa.
				case 0:
					break;

				//Insertar un escritor en el fichero binario.
				case 1:
					nombre = Teclado.leerCadena("Nombre: ");
					fechaNacimiento = Teclado.leerCadena("Fecha de nacimiento: ");
					nacionalidad = Teclado.leerCadena("Nacionalidad: ");
					escritor = new Escritor(nombre, fechaNacimiento, nacionalidad);
					AccesoEscritores.insertarEscritor(escritor, ficheroEscritores);
					System.out.println("Se ha insertado un escritor "
										+ "en el fichero binario.");
					break;

				//Consultar todos los escritores del fichero binario.
				case 2:
					listaEscritores = AccesoEscritores.leerTodos(ficheroEscritores);
					visualizarColeccionEscritores(listaEscritores);
					break;

				//Consultar un escritor, por c�digo, del fichero binario.
				case 3:
					codigo = Teclado.leerNatural("C�digo: ");
					escritor = AccesoEscritores.
							consultarEscritor(ficheroEscritores, codigo);
					if (escritor == null) {
						System.out.println("No existe ning�n escritor con"
										+ " ese c�digo en el fichero binario.");
					}
					else {
						System.out.println(escritor.toString());
					}
					break;

				//Actualizar un escritor, por c�digo, del fichero binario.
				case 4:
					codigo = Teclado.leerNatural("C�digo: ");
					nombre = Teclado.leerCadena("Nombre: ");
					fechaNacimiento = Teclado.leerCadena("Fecha de nacimiento: ");
					nacionalidad = Teclado.leerCadena("Nacionalidad: ");
					escritor = new Escritor(nombre, fechaNacimiento, nacionalidad);
					Escritor.setGeneradorCodigo(Escritor.getGeneradorCodigo() - 1);
					if (AccesoEscritores.actualizarEscritor(ficheroEscritores,
							codigo, escritor)) {
						System.out.println("Se ha actualizado un escritor del"
										+ " fichero binario.");
					}
					else {
						System.out.println("No existe ning�n escritor con"
										+ " ese codigo en el fichero binario.");
					}
					break;

				//Eliminar un escritor, por c�digo, del fichero binario.
				case 5:
					codigo = Teclado.leerNatural("C�digo: ");
					if (AccesoEscritores.eliminarEscritor(ficheroEscritores, codigo)) {
						System.out.println("Se ha eliminado un escritor del"
										+ " fichero binario.");
					}
					else {
						System.out.println("No existe ning�n escritor con"
										+ " ese codigo en el fichero binario.");
					}
					break;

				//Visualizar mensaje de error por no ser una opcion correcta.
				default:
					System.out.println("La opci�n debe estar entre 0 y 5.");
					break;

				}
			}
			catch (FileNotFoundException fnfe) {                      
				System.out.println("Error al abrir el fichero: " + fnfe.getMessage());
				fnfe.printStackTrace();
			}
			catch (IOException ioe) {
				System.out.println("Error al leer/escribir de/en el fichero: " + ioe.getMessage());
				ioe.printStackTrace();
			}
			
		} while (opcion != 0);
	}
	
	//Visualiza una coleccion de escritores
	public static void visualizarColeccionEscritores(Collection<Escritor> coleccion) {
		if (coleccion.size() == 0) {
			System.out.println("El fichero binario no tiene ning�n escritor.");
		}
		else {
			for (Escritor escritor : coleccion) {
				System.out.println(escritor.toString());
			}
			System.out.println("Se han consultado " + coleccion.size()
							+ " escritores.");
		}
	}

}