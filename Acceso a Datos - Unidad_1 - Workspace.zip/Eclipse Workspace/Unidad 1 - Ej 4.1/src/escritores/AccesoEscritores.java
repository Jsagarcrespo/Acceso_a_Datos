package escritores;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;

public class AccesoEscritores {
	//Escribe un objeto en un fichero binario
	public static void insertarEscritor(Escritor escritor, File fichero)
			throws IOException {
		RandomAccessFile flujoEscritura = null;
		try {
			flujoEscritura = new RandomAccessFile(fichero, "rw");
			flujoEscritura.seek(flujoEscritura.length());
			
			//Escribimos el objeto dato por dato en el fichero binario
			flujoEscritura.writeInt(escritor.getCodigo());
			flujoEscritura.writeChars(escritor.getNombre());
			flujoEscritura.writeChars(escritor.getFechaNacimiento());
			flujoEscritura.writeChars(escritor.getNacionalidad());
		}
		finally {
			if (flujoEscritura != null) {
				flujoEscritura.close();
			}
		}
	}

	//Lee los objetos de un fichero binario y la guarda en una lista de escritores
	public static List<Escritor> leerTodos(File fichero)
			throws FileNotFoundException, IOException {
		List<Escritor> listaEscritores = new ArrayList<Escritor>();
		RandomAccessFile flujoLectura = null;
		try {
			Escritor escritor;
			int codigo;
			String nombre, fechaNacimiento, nacionalidad;
			flujoLectura = new RandomAccessFile(fichero, "r");
			flujoLectura.seek(0);			
			while (flujoLectura.getFilePointer() < flujoLectura.length()) {
				//Obtenemos el c�digo del escritor
				codigo = flujoLectura.readInt();
				
				//Si el c�digo es mayor que 0, no estar� eliminado
				if (codigo > 0) {
					//Obtenemos el nombre del escritor
					char[] vectorNombre = new char[Escritor.getLongitudStrings()];
					for (int i = 0 ; i < vectorNombre.length ; i++) {         
						vectorNombre[i] = flujoLectura.readChar(); 
					}
					nombre = new String(vectorNombre);
					
					//Obtenemos la fecha de nacimiento del escritor
					char[] vectorFecha = new char[Escritor.getLongitudFecha()];
					for (int i = 0 ; i < vectorFecha.length ; i++) {         
						vectorFecha[i] = flujoLectura.readChar(); 
					}
					fechaNacimiento = new String(vectorFecha);
					
					//Obtenemos el nombre del escritor
					char[] vectorNacionalidad = new char[Escritor.getLongitudStrings()];
					for (int i = 0 ; i < vectorNacionalidad.length ; i++) {         
						vectorNacionalidad[i] = flujoLectura.readChar(); 
					}
					nacionalidad = new String(vectorNacionalidad);
					
					escritor = new Escritor(codigo, nombre, fechaNacimiento, nacionalidad);
					listaEscritores.add(escritor);
				}
				else {
					flujoLectura.seek(flujoLectura.getFilePointer() +
										Escritor.getTamanoRegistro() - 4);
				}
			}
		}
		finally {
			if (flujoLectura != null) {
				flujoLectura.close();
			}
		}

		return listaEscritores;
	}
	
	//Consulta un escritor a partir de un codigo en el fichero binario
	public static Escritor consultarEscritor(File fichero, int codigo) 
			throws FileNotFoundException, IOException {
		RandomAccessFile flujoLectura = null;
		Escritor escritor = null;
		try {
			flujoLectura = new RandomAccessFile(fichero, "r");
			int posicion = (codigo - 1) * Escritor.getTamanoRegistro();
			if (posicion >= 0 && posicion < flujoLectura.length()) {
				flujoLectura.seek(posicion);
				
				//Obtenemos el c�digo del escritor
				codigo = flujoLectura.readInt();
				
				//Si el c�digo es mayor que 0, no estar� eliminado
				if (codigo > 0) {
					//Obtenemos el nombre del escritor
					char[] vectorNombre = new char[Escritor.getLongitudStrings()];
					for (int i = 0 ; i < vectorNombre.length ; i++) {         
						vectorNombre[i] = flujoLectura.readChar(); 
					}
					String nombre = new String(vectorNombre);
					
					//Obtenemos la fecha de nacimiento del escritor
					char[] vectorFecha = new char[Escritor.getLongitudFecha()];
					for (int i = 0 ; i < vectorFecha.length ; i++) {         
						vectorFecha[i] = flujoLectura.readChar(); 
					}
					String fechaNacimiento = new String(vectorFecha);
					
					//Obtenemos el nombre del escritor
					char[] vectorNacionalidad = new char[Escritor.getLongitudStrings()];
					for (int i = 0 ; i < vectorNacionalidad.length ; i++) {         
						vectorNacionalidad[i] = flujoLectura.readChar(); 
					}
					String nacionalidad = new String(vectorNacionalidad);
					
					escritor = new Escritor(codigo, nombre, fechaNacimiento, nacionalidad);
				}
				else {
					flujoLectura.seek(flujoLectura.getFilePointer() +
										Escritor.getTamanoRegistro() - 4);
				}
			}
			return escritor;
		}
		finally {
			if (flujoLectura != null) {
				flujoLectura.close();
			}
		}
	}

	//Actualiza el escritor a partir de un codigo en el fichero binario
	public static boolean actualizarEscritor(File fichero, int codigo, Escritor escritor)
			throws FileNotFoundException, IOException {
		RandomAccessFile flujoEscritura = null;
		boolean encontrado = false;
		try {
			flujoEscritura = new RandomAccessFile(fichero, "rw");
			int posicion = (codigo - 1) * Escritor.getTamanoRegistro();
			if (posicion > 0 && posicion < flujoEscritura.length()) {
				flujoEscritura.seek(posicion);
				
				int codigoEnFichero = flujoEscritura.readInt();
				if (codigo == codigoEnFichero) {
					encontrado = true;
					
					//Sustituimos el objeto dato por dato en el fichero binario
					flujoEscritura.writeChars(escritor.getNombre());
					flujoEscritura.writeChars(escritor.getFechaNacimiento());
					flujoEscritura.writeChars(escritor.getNacionalidad());
				}
			}
		}
		finally {
			if (flujoEscritura != null) {
				flujoEscritura.close();
			}
		}

		return encontrado;

	}

	//Elimina un escritor a partir de un codigo en el fichero binario
	public static boolean eliminarEscritor(File fichero, int codigo) 
			throws FileNotFoundException, IOException {
		RandomAccessFile flujoEscritura = null;
		boolean encontrado = false;
		try {
			flujoEscritura = new RandomAccessFile(fichero, "rw");
			int posicion = (codigo - 1) * Escritor.getTamanoRegistro();
			if (posicion >= 0 && posicion < flujoEscritura.length()) {
				encontrado = true;
				flujoEscritura.seek(posicion);
				
				//Modificamos el c�digo del escritor
				flujoEscritura.writeInt(0);
			}
		}
		finally {
			if (flujoEscritura != null) {
				flujoEscritura.close();
			}
		}

		return encontrado;

	}

}
