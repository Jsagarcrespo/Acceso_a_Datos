package contar_palabras;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import entrada.Teclado;

public class ContarPalabras {
	public static List<String> cargar(File fichero)
			throws FileNotFoundException, IOException {
		List<String> listaLineas = new ArrayList<String>();
		BufferedReader flujoLectura = null;
		try {
			flujoLectura = new BufferedReader(new FileReader(fichero));
			String lineaActual;
			lineaActual = flujoLectura.readLine();
			while (lineaActual != null) {
				listaLineas.add(lineaActual);
				lineaActual = flujoLectura.readLine();
			}
		}
		finally {
			if (flujoLectura != null) {
				flujoLectura.close();
			}
		}

		return listaLineas;
	}

	public static void guardar(List<String> listaLineas, File ficheroSalida)
			throws IOException {
		BufferedWriter flujoEscritura = null;
		try {
			flujoEscritura = new BufferedWriter(new FileWriter(ficheroSalida, false));
			for (String lineaActual : listaLineas) {
				flujoEscritura.write(lineaActual);
				flujoEscritura.newLine();
			}
		}
		finally {
			if (flujoEscritura != null) {
				flujoEscritura.close();
			}
		}
	}

	public static List<String> generarEstadisticas(List<String> listaLineas) {
		List<String> listaEstadisticas = new ArrayList<String>();
		String estadisticasLinea;
		String estadisticasTotales;
		int contadorLinea = 0;
		int contadorPalabras = 0;
		int contadorCaracteres = 0;
		for (String lineaActual : listaLineas) {
			contadorLinea++;
			contadorPalabras += contarPalabras(lineaActual);
			contadorCaracteres += lineaActual.length();

			estadisticasLinea = "L�nea " + contadorLinea + " ---> " +
					"N�mero de car�cteres: " + lineaActual.length() + 
					", N�mero de palabras: " + contarPalabras(lineaActual);
			listaEstadisticas.add(estadisticasLinea);
		}
		estadisticasTotales = "Total --> N�mero de l�neas: " + contadorLinea
				+ ", N�mero de car�cteres: " + contadorCaracteres
				+ " y N�mero de palabras: " + contadorPalabras;
		listaEstadisticas.add(estadisticasTotales);

		return listaEstadisticas;
	}

	public static int contarPalabras(String linea) {
		int contadorEspacios = 0;
		linea = linea.trim();

		for (int i = 0; i < linea.length(); i++) {
			if (linea.charAt(i) == ' ') {
				contadorEspacios++;
				if (linea.charAt(i + 1) == ' ') {
					contadorEspacios--;
				}
			}
		}

		if (linea.length() > 0) {
			return contadorEspacios + 1;
		}
		else {
			return 0;
		}
	}

	public static void main(String[] args) {
		try {
			String nombreArchivo = Teclado.leerCadena("Nombre del archivo: ");
			File fichero = new File("data\\" + nombreArchivo);
			if (!fichero.exists()) {
				System.out.println("El archivo no existe en el sistema de archivos.");
			}
			else if (!fichero.isFile()) {
				System.out.println("El archivo no es un fichero.");
			}
			else {
				List<String> listaLineas = cargar(fichero);
				List<String> listaEstadisticas = generarEstadisticas(listaLineas);
				File ficheroSalida = new File("data\\estadisticas.txt");
				guardar(listaEstadisticas, ficheroSalida);
				
				System.out.println("Las estad�sticas se han generado correctamente.");
			}
		}
		catch (FileNotFoundException fnfe) {                      
			System.out.println("Error al abrir el fichero: " + fnfe.getMessage());
			fnfe.printStackTrace();
		}
		catch (IOException ioe) {
			System.out.println("Error al leer del fichero: " + ioe.getMessage());
			ioe.printStackTrace();
		}
	}
}
