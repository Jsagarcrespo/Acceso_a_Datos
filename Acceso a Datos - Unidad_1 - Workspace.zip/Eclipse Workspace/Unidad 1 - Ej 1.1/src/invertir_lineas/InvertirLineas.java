package invertir_lineas;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class InvertirLineas {
	public static void main(String[] args) {
		List<String> listaLineas = new ArrayList<String>();
		BufferedReader flujoLectura = null;
		BufferedWriter flujoEscritura = null;
		try {
			//Leer el fichero y guardar sus l�neas en una lista
			File ficheroEntrada = new File("data\\entrada.txt");
			flujoLectura = new BufferedReader(new FileReader(ficheroEntrada));
			String lineaActual;
			lineaActual = flujoLectura.readLine();
			while (lineaActual != null) {
				listaLineas.add(lineaActual);
				lineaActual = flujoLectura.readLine();
      		}
			
			//Guardar las l�neas de la lista en el nuevo fichero en orden inverso
			File ficheroSalida = new File("data\\salida.txt");
			flujoEscritura = new BufferedWriter(new FileWriter(ficheroSalida, false));
			for (int i = listaLineas.size() - 1; i >= 0; i--) {
				lineaActual = listaLineas.get(i);
				flujoEscritura.write(lineaActual);
				flujoEscritura.newLine();
			}
			
			System.out.println("Las l�neas se han copiado correctamente de forma inversa.");
		}
		catch (FileNotFoundException fnfe) {                      
			System.out.println("Error al abrir el fichero:");
			System.out.println(fnfe.getMessage());
			fnfe.printStackTrace();
		}
		catch (IOException ioe) {
			System.out.println("Error al leer del fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		}
		finally {
			try {
				if (flujoLectura != null) {
					flujoLectura.close();
				}
				if (flujoEscritura != null) {
					flujoEscritura.close();
				}
			}
			catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}
		}
	}
}
