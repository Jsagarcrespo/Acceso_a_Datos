package departamentos;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collection;
import java.util.List;

import entrada.Teclado;

public class PrincipalDepartamentos {

	//Visualizar el menu de opciones
	public static void escribirMenuOpciones() {
		System.out.println("\n0) Salir del programa");
		System.out.println("1) Insertar un departamento en el fichero de texto.");
		System.out.println("2) Consultar todos los departamentos del fichero de texto.");
		System.out.println("3) Consultar un departamento, por c�digo, del fichero de texto.");
		System.out.println("4) Actualizar un departamento, por c�digo, del fichero de texto.");
		System.out.println("5) Eliminar un departamento, por c�digo, del fichero de texto.");
	}

	public static void main(String[] args) {
		File ficheroDepartamentos = new File("data\\departamentos.txt");
		int opcion, codigo;
		String nombre, ubicacion;
		Departamento departamento;
		List<Departamento> listaDepartamentos;

		do {
			escribirMenuOpciones();
			opcion = Teclado.leerEntero("\nSelecciona una opci�n: ");
			
			try {
				switch (opcion) {
				//Salir del programa.
				case 0:
					break;

				//Insertar un departamento en el fichero de texto.
				case 1:
					codigo = Teclado.leerNatural("C�digo departamento: ");
					if (AccesoDepartamentos.consultarDepartamento(ficheroDepartamentos, codigo) == null) {
						nombre = Teclado.leerCadena("Nombre: ");
						ubicacion = Teclado.leerCadena("Ubicaci�n: ");
						departamento = new Departamento(codigo, nombre, ubicacion);
						AccesoDepartamentos.insertarDepartamento(departamento, ficheroDepartamentos);
						System.out.println("Se ha insertado un departamento "
											+ "en el fichero de texto.");
					}
					else {
						System.out.println("Ya existe otro departamento con ese "
											+ "codigo en el fichero de texto.");
					}
					break;

				//Consultar todos los departamentos del fichero de texto.
				case 2:
					listaDepartamentos = AccesoDepartamentos.leerTodos(ficheroDepartamentos);
					visualizarColeccionDepartamentos(listaDepartamentos);
					break;

				//Consultar un departamento, por c�digo, del fichero de texto.
				case 3:
					codigo = Teclado.leerNatural("C�digo: ");
					departamento = AccesoDepartamentos.
							consultarDepartamento(ficheroDepartamentos, codigo);
					if (departamento == null) {
						System.out.println("No existe ning�n departamento con"
										+ " ese c�digo en el fichero de texto.");
					}
					else {
						System.out.println(departamento.toString());
					}
					break;

				//Actualizar un departamento, por c�digo, del fichero de texto.
				case 4:
					codigo = Teclado.leerNatural("C�digo: ");
					nombre = Teclado.leerCadena("Nombre: ");
					ubicacion = Teclado.leerCadena("Ubicaci�n: ");
					if (AccesoDepartamentos.actualizarDepartamento(ficheroDepartamentos, codigo, nombre, ubicacion)) {
						System.out.println("Se ha actualizado un departamento del"
										+ " fichero de texto");
					}
					else {
						System.out.println("No existe ning�n departamento con"
										+ " ese codigo en el fichero de texto.");
					}
					break;

				//Eliminar un departamento, por c�digo, del fichero de texto.
				case 5:
					codigo = Teclado.leerNatural("C�digo: ");
					if (AccesoDepartamentos.eliminarDepartamento(ficheroDepartamentos, codigo)) {
						System.out.println("Se ha eliminado un departamento del"
										+ " fichero de texto");
					}
					else {
						System.out.println("No existe ning�n departamento con"
										+ " ese codigo en el fichero de texto.");
					}
					break;

				//Visualizar mensaje de error por no ser una opcion correcta.
				default:
					System.out.println("La opci�n debe estar entre 0 y 5.");
					break;

				}
			}
			catch (FileNotFoundException fnfe) {                      
				System.out.println("Error al abrir el fichero: " + fnfe.getMessage());
				fnfe.printStackTrace();
			}
			catch (IOException ioe) {
				System.out.println("Error al leer/escribir de/en el fichero: " + ioe.getMessage());
				ioe.printStackTrace();
			}
			
		} while (opcion != 0);
	}
	
	//Visualiza una coleccion de departamentos
	public static void visualizarColeccionDepartamentos(Collection<Departamento> coleccion) {
		if (coleccion.size() == 0) {
			System.out.println("El fichero de texto esta vac�o.");
		}
		else {
			for (Departamento departamento : coleccion) {
				System.out.println(departamento.toString());
			}
			System.out.println("Se han consultado " + coleccion.size()
							+ " departamentos.");
		}
	}

}