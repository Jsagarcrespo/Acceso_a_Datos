package departamentos;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AccesoDepartamentos {
	//Busca un departamento a partir de un codigo en el fichero de texto
	/*public static boolean buscarDepartamento(File fichero, int codigo) 
			throws FileNotFoundException, IOException {
		BufferedReader flujoLectura = null;
		boolean encontrado = false;
		try {
			if (fichero.exists()) {
				flujoLectura = new BufferedReader(new FileReader(fichero));
				String linea = flujoLectura.readLine();
				Departamento departamento;
				while (linea != null && !encontrado) {
					departamento = new Departamento(linea);
					if (departamento.getCodigo() == codigo) {
						encontrado = true;
					}
					linea = flujoLectura.readLine();
				}
			}
		}
		finally {
			if (flujoLectura != null) {
				flujoLectura.close();
			}
		}

		return encontrado;
	}*/

	//Escribe una linea en un fichero de texto
	public static void insertarDepartamento(Departamento departamento, File fichero)
			throws IOException {
		BufferedWriter flujoEscritura = null;
		try {
			flujoEscritura = new BufferedWriter(new FileWriter(fichero, true));
			String linea = departamento.toStringWithSeparators();
			flujoEscritura.write(linea);
			flujoEscritura.newLine();
		}
		finally {
			if (flujoEscritura != null) {
				flujoEscritura.close();
			}
		}
	}

	//Lee las lineas de un fichero de texto y la guarda en una lista de departamentos
	public static List<Departamento> leerTodos(File fichero)
			throws FileNotFoundException, IOException {
		List<Departamento> listaDepartamentos = new ArrayList<Departamento>();
		BufferedReader flujoLectura = null;
		try {
			Departamento departamento;
			flujoLectura = new BufferedReader(new FileReader(fichero));
			String linea = flujoLectura.readLine();
			while (linea != null) { 	 
				departamento = new Departamento(linea);
				listaDepartamentos.add(departamento);
				linea = flujoLectura.readLine();
			}
		}
		finally {
			if (flujoLectura != null) {
				flujoLectura.close();
			}
		}

		return listaDepartamentos;
	}

	//Consulta un departamento a partir de un codigo en el fichero de texto
	public static Departamento consultarDepartamento(File fichero, int codigo) 
			throws FileNotFoundException, IOException {
		BufferedReader flujoLectura = null;
		Departamento departamento = null;
		try {
			if (fichero.exists()) {
				flujoLectura = new BufferedReader(new FileReader(fichero));
				boolean encontrado = false;
				String linea = flujoLectura.readLine();
				while (linea != null && !encontrado) {
					departamento = new Departamento(linea);
					if (departamento.getCodigo() == codigo) {
						encontrado = true;
					}
					linea = flujoLectura.readLine();
				}

				if (! encontrado) {
					departamento = null;
				}
			}
		}
		finally {
			if (flujoLectura != null) {
				flujoLectura.close();
			}
		}
		return departamento;
	}

	//Actualiza el departamento y el salario de un departamento
	//a partir de un codigo en el fichero de texto
	public static boolean actualizarDepartamento(File fichero, int codigo,
			String nombre, String ubicacion) throws FileNotFoundException, IOException {
		List<Departamento> listaDepartamentos = leerTodos(fichero);
		boolean encontrado = false;
		int posicionActualizar = 0;
		Departamento departamento;
		for (int i = 0; i < listaDepartamentos.size() && !encontrado; i++) {
			departamento = listaDepartamentos.get(i);
			if (departamento.getCodigo() == codigo) {
				encontrado = true;
				posicionActualizar = i;
			}
		}
		if (encontrado) {
			departamento = listaDepartamentos.get(posicionActualizar);
			departamento.setNombre(nombre);
			departamento.setUbicacion(ubicacion);
			escribirTodos(listaDepartamentos, fichero);
		}

		return encontrado;

	}

	//Elimina un departamento a partir de un codigo en el fichero de texto
	public static boolean eliminarDepartamento(File fichero, int codigo) 
			throws FileNotFoundException, IOException {
		List<Departamento> listaDepartamentos = leerTodos(fichero);
		boolean encontrado = false;
		int posicionEliminar = 0;
		Departamento departamento;
		for (int i = 0; i < listaDepartamentos.size() && !encontrado; i++) {
			departamento = listaDepartamentos.get(i);
			if (departamento.getCodigo() == codigo) {
				encontrado = true;
				posicionEliminar = i;
			}
		}
		if (encontrado) {
			listaDepartamentos.remove(posicionEliminar);
			escribirTodos(listaDepartamentos, fichero);
		}

		return encontrado;

	}

	//Guarda cada elemento de una lista de departamentos en un fichero
	public static void escribirTodos(List<Departamento> listaDepartamentos,
			File ficheroDepartamentos) throws IOException {
		BufferedWriter flujoEscritura = null;
		try {
			flujoEscritura = new BufferedWriter(new FileWriter(ficheroDepartamentos, false));
			Departamento departamento;
			String linea;
			for (int i = 0; i < listaDepartamentos.size(); i++) {
				departamento = listaDepartamentos.get(i);
				linea = departamento.toStringWithSeparators();
				flujoEscritura.write(linea);
				flujoEscritura.newLine();
			}
		}
		finally {
			if (flujoEscritura != null) {
				flujoEscritura.close();
			}
		}

	}

}
