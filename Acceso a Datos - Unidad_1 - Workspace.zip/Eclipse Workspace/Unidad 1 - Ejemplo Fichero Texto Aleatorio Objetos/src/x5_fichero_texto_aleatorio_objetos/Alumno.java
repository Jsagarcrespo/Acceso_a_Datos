package x5_fichero_texto_aleatorio_objetos;

public class Alumno {
	
	private static final String SEPARADOR = ";";
	private static final int LONGITUD_REGISTRO = 44; 
	// con 2 caracteres separadores ';'
	// con un salto de l�nea formado por 2 caracteres '\r' y '\n'
	
	// atributos de objeto
	private int codigo;     // 3 caracteres
	private String nombre;  // 30 caracteres
	private double nota;    // 7 caracteres
	
	// Crea un alumno a partir de 3 par�metros.
	public Alumno(int codigo, String nombre, double nota) {
		this.codigo = codigo;
		StringBuffer buffer = new StringBuffer(nombre);
		buffer.setLength(30);
		this.nombre = buffer.toString();
		this.nota = nota;
	}
	
	// Crea un alumno a partir de una l�nea.
	public Alumno(String linea) {
		String[] datos = linea.split(SEPARADOR);
		this.codigo = Integer.parseInt(datos[0]);
		this.nombre = datos[1];
		this.nota = Double.parseDouble(datos[2]);
	}
		
	// Devuelve una cadena de caracteres con el estado del alumno.
	// Se utiliza para escribir el alumno en consola.
	@Override
	public String toString() {
		return 
			"Alumno [C�digo = " + this.codigo +
			", Nombre = " + this.nombre.trim() +
			", Nota = " + String.format("%.2f", this.nota) +
			"]";
	}

	// Devuelve una cadena de caracteres con el estado del alumno.
	// Se utiliza para escribir el alumno en un fichero de texto.
	public String toStringWithFixedLength() {
		return 
			String.format("%03d", this.codigo) + SEPARADOR +
			this.nombre + SEPARADOR +
			String.format("%07.4f", this.nota).replace(',', '.');
	}
		
	// Devuelve la longitud de registro del alumno.
	public static int getLongitudRegistro() {
		return LONGITUD_REGISTRO;
	}
	
	// Devuelve el tama�o de registro del alumno.
	// Cada car�cter del alumno se almacena con 1 byte en el fichero de texto.
	public static int getTamagnoRegistro() {
		return LONGITUD_REGISTRO;
	}

	// Devuelve el c�digo del alumno.
	public int getCodigo() {
		return this.codigo;
	}

}
