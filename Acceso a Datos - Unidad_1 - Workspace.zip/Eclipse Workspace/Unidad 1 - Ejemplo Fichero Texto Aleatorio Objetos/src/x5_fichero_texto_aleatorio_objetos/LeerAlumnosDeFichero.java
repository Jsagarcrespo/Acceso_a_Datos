package x5_fichero_texto_aleatorio_objetos;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

public class LeerAlumnosDeFichero {
  
	// Lee todos los alumnos del fichero de texto 'alumnos_aleat.txt',
	// escribe en consola estos alumnos y
	// escribe en consola el n�mero de alumnos le�dos del fichero de texto.
  	public static void main(String[] args) {
		RandomAccessFile flujoEntrada = null;
		try {
			File fichero = new File("data\\alumnos_aleat.txt");
			flujoEntrada = new RandomAccessFile(fichero, "r");
			flujoEntrada.seek(0);			
			int contadorAlumnos = 0;
			while (flujoEntrada.getFilePointer() < flujoEntrada.length()) {
				byte[] vectorBytes = new byte[Alumno.getLongitudRegistro()];
				flujoEntrada.readFully(vectorBytes);
				String linea = new String(vectorBytes);
				Alumno alumno = new Alumno(linea);
				if (alumno.getCodigo() > 0) {
					System.out.println(alumno.toString());
					contadorAlumnos++;
				}
			}
			System.out.println("Se han le�do " + contadorAlumnos + 
                               " alumnos del fichero de texto.");
		} 
		catch (FileNotFoundException fnfe) {
			System.out.println("Error al abrir el fichero:");
			System.out.println(fnfe.getMessage());
			fnfe.printStackTrace();
		}
		catch (IOException ioe) {
			System.out.println("Error al leer del fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		}
		finally {
			try {
				if (flujoEntrada != null) {
					flujoEntrada.close();
				}
			}
			catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}
		}
	}
  
}
