package x5_fichero_texto_aleatorio_objetos;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import entrada.Teclado;

public class EscribirAlumnoEnFichero {
  
	// Lee por teclado los datos de un alumno y
	// escribe este alumno al final del fichero de texto 'alumnos_aleat.txt'.
  	public static void main(String[] args) {
		RandomAccessFile flujoSalida = null;
		try {
			String nombre = Teclado.leerCadena("�Nombre? ");
			double nota = Teclado.leerReal("�Nota? ");
			File fichero = new File("data\\alumnos_aleat.txt");
			flujoSalida = new RandomAccessFile(fichero, "rw");
			long posicion = flujoSalida.length();
			flujoSalida.seek(posicion);
			int tamagnoRegistro = Alumno.getTamagnoRegistro();
			int codigo = (int) ((posicion + tamagnoRegistro) / tamagnoRegistro);
			Alumno alumno = new Alumno(codigo, nombre, nota);
			flujoSalida.writeBytes(alumno.toStringWithFixedLength());
			flujoSalida.writeBytes("\r\n");
			System.out.println("Se ha escrito un alumno con c�digo " + codigo + 
			                   " en el fichero de texto.");
		} 
		catch (FileNotFoundException fnfe) {
			System.out.println("Error al crear o abrir el fichero:");
			System.out.println(fnfe.getMessage());
			fnfe.printStackTrace();
		}
		catch (IOException ioe) {
			System.out.println("Error al escribir en el fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		}
		finally {
			try {
				if (flujoSalida != null) {
					flujoSalida.close();
				}
			}
			catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}
		}
	}
  
}
